// BELOVED service worker: makes the app work offline. Bump V when you publish a new version.
const V = 'beloved-v1';
const CORE = ['./', 'index.html', 'firebase-config.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'maskable-512.png', 'apple-touch-icon.png'];
const FB = 'https://www.gstatic.com/firebasejs/10.12.2/';

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await c.addAll(CORE);
    // best effort: keep the sign-in library so it still loads with no internet
    await Promise.all([FB + 'firebase-app.js', FB + 'firebase-auth.js'].map(u =>
      fetch(u, { mode: 'cors' }).then(r => r.ok && c.put(u, r)).catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== V) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  const lib = u.href.startsWith('https://www.gstatic.com/firebasejs/') || u.hostname === 'fonts.googleapis.com' || u.hostname === 'fonts.gstatic.com';
  if (r.mode === 'navigate') {
    // open pages from the network when online (so updates arrive), from the saved copy when offline
    e.respondWith(fetch(r).then(x => { const cp = x.clone(); caches.open(V).then(c => c.put('index.html', cp)); return x; })
      .catch(() => caches.match('index.html', { ignoreSearch: true })));
    return;
  }
  if (lib) {
    e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(x => {
      if (x && (x.ok || x.type === 'opaque')) { const cp = x.clone(); caches.open(V).then(c => c.put(r, cp)); }
      return x;
    })));
    return;
  }
  if (u.origin === location.origin) {
    e.respondWith(caches.match(r).then(hit => {
      const net = fetch(r).then(x => { if (x.ok) { const cp = x.clone(); caches.open(V).then(c => c.put(r, cp)); } return x; }).catch(() => hit);
      return hit || net;
    }));
  }
});

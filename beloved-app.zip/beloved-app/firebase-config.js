// Paste your Firebase web app settings here (Firebase console > Project settings > Your apps).
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  appId: "PASTE_APP_ID"
};
